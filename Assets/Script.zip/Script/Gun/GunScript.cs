﻿using UnityEngine;

public class GunScript : MonoBehaviour
{

   [SerializeField] private SpriteRenderer spriteRenderer; // 무기 스프라이트
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        RotateGun();
    }

    private void RotateGun()
    {
        Vector3 mouseScreenPos = Input.mousePosition;   // 마우스좌표값
        Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(mouseScreenPos); // 게임월드 좌표값으로 변경
        Vector2 direction = mouseWorldPos - transform.position;   // 오브젝트(총)에서 마우스까지의 거리 계산

        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;  // 방향 벡터를 각도로 변경
        if (direction.x < 0)
        {
            spriteRenderer.flipY = true;
        }
        else
        {
            spriteRenderer.flipY = false;
        }

        transform.rotation = Quaternion.Euler(0, 0, angle);  // 최종 오브젝트 회전

    }

}
