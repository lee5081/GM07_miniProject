﻿using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] protected Rigidbody2D rb;
    [SerializeField] protected SpriteRenderer spriteRenderer;

    protected BulletData data;
    protected float damage;
    protected int remainingPierce;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }
    public virtual void Initialize(BulletData bulletData, Vector2 direction, float damageMultiplier = 1f)
    {
        data = bulletData;

        damage = data.damage * damageMultiplier;
        remainingPierce = data.pierceCount;

        spriteRenderer.sprite = data.sprite;

        rb.linearVelocity = direction.normalized * data.speed;

        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        transform.rotation = Quaternion.Euler(0f, 0f, angle);

        Destroy(gameObject, data.lifeTime);
    }

    protected virtual void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.TryGetComponent(out IDamageable damageable))
        {
            damageable.TakeDamage(damage);

            OnHit(collision);

            if (remainingPierce > 0)
            {
                remainingPierce--;
            }
            else
            {
                Destroy(gameObject);
            }
        }
    }

    protected virtual void OnHit(Collider2D collision)
    {

    }
}