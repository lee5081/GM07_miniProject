﻿using System.Collections;
using UnityEngine;

public class Gun : MonoBehaviour
{
    [SerializeField] protected GunData data;
    [SerializeField] protected Transform firePoint;
    [SerializeField] private SpriteRenderer weaponRenderer;
    [SerializeField] protected BulletData bulletData;
    protected int currentAmmo;
    protected float nextFireTime;
    protected bool isReloading;

    public int CurrentAmmo => currentAmmo;
    public int MagazineSize => data.magazineSize;

    protected virtual void Awake()
    {
        currentAmmo = data.magazineSize;

        if (weaponRenderer != null)
        {
            weaponRenderer.sprite = data.weaponSprite;
        }
    }

    public virtual void TryFire(Vector2 direction)
    {
        if (isReloading)
            return;

        if (Time.time < nextFireTime)
            return;

        if (currentAmmo <= 0)
        {
            TryReload();
            return;
        }

        nextFireTime = Time.time + data.fireInterval;
        currentAmmo--;

        Fire(direction);
    }

    protected virtual void Fire(Vector2 direction)
    {
        int count = Mathf.Max(1, data.bulletCount);

        for (int i = 0; i < count; i++)
        {
            float spread =
                Random.Range(-data.spreadAngle * 0.5f,
                              data.spreadAngle * 0.5f);

            Vector2 shotDirection =
                Quaternion.Euler(0f, 0f, spread) * direction;

            SpawnBullet(shotDirection);
        }
    }

    protected void SpawnBullet(Vector2 direction)
    {
        Bullet bullet = Instantiate(
            data.bulletPrefab,
            firePoint.position,
            Quaternion.identity
        );

        bullet.Initialize(
            bulletData,
            direction,         
            data.damage
        );
    }

    public void TryReload()
    {
        if (isReloading)
            return;

        if (currentAmmo >= data.magazineSize)
            return;

        StartCoroutine(ReloadCoroutine());
    }

    private IEnumerator ReloadCoroutine()
    {
        isReloading = true;

        yield return new WaitForSeconds(data.reloadTime);

        currentAmmo = data.magazineSize;
        isReloading = false;
    }
}