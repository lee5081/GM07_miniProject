﻿using UnityEngine;

public class PlayerGunController : MonoBehaviour
{
    [SerializeField] private Transform weaponHolder;

    [SerializeField] private Gun currentGun;

    public void EquipWeapon(Gun weaponPrefab)
    {
        if (currentGun != null)
        {
            Destroy(currentGun.gameObject);
        }

        currentGun = Instantiate(
            weaponPrefab,
            weaponHolder.position,
            weaponHolder.rotation,
            weaponHolder
        );
    }

    public void Fire(Vector2 direction)
    {
        if (currentGun == null)
            return;

        currentGun.TryFire(direction);
    }

    public void Reload()
    {
        if (currentGun == null)
            return;

        currentGun.TryReload();
    }
}