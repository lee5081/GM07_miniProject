﻿using UnityEngine;

public class PlayerController : MonoBehaviour
{

    private PlayerMovement movement;
    private PlayerGunController gunController;
    private PlayerAim aim;
    private void Awake()
    {
        movement = GetComponent<PlayerMovement>();
        gunController = GetComponent<PlayerGunController>();
        aim = GetComponent<PlayerAim>();
    }

    private void Start()
    {

    }


    private void Update()
    {
        HandleMovement();
        HandleFire();
    }


    private void HandleFire()
    {
        if (Input.GetMouseButton(0))
        {
            gunController.Fire(aim.AimDirection);
        }
        if (Input.GetKeyDown(KeyCode.R))
        {
            gunController.Reload();
        }

    }

    private void HandleMovement()
    {
        Vector2 moveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")).normalized;
        movement.SetMoveInput(moveInput);

    }


}

